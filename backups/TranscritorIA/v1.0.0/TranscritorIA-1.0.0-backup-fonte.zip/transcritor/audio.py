"""Leitura de áudio (MP3, M4A, WAV, OGG, FLAC, AAC, WMA, OPUS, vídeos MP4...).

Usa PyAV (FFmpeg embutido) — o usuário não instala FFmpeg. O áudio é convertido
para 16 kHz mono float32, formato nativo do Whisper. Uma aula de 3 h ocupa
~690 MB em RAM, valor verificado contra a RAM livre antes do processamento.
"""
from __future__ import annotations

import wave
from pathlib import Path

import numpy as np

SR = 16000
AUDIO_EXTS = {".mp3", ".m4a", ".wav", ".ogg", ".oga", ".flac", ".aac", ".wma", ".opus",
              ".webm", ".mp4", ".mkv", ".mov", ".amr", ".3gp", ".mpga", ".m4b"}


class AudioError(Exception):
    pass


def probe_duration(path: str | Path) -> float:
    """Duração em segundos sem decodificar o arquivo inteiro."""
    import av

    try:
        with av.open(str(path)) as c:
            if c.duration:
                return float(c.duration) / 1_000_000.0
            st = next((s for s in c.streams if s.type == "audio"), None)
            if st is not None and st.duration and st.time_base:
                return float(st.duration * st.time_base)
    except Exception as e:  # arquivo corrompido / não suportado
        raise AudioError(f"Não foi possível ler o áudio: {e}") from e
    return 0.0


def decode(path: str | Path, cancel=None) -> np.ndarray:
    """Decodifica para 16 kHz mono float32 (independente da versão do PyAV)."""
    import av

    parts = []
    try:
        with av.open(str(path)) as c:
            st = next((s for s in c.streams if s.type == "audio"), None)
            if st is None:
                raise AudioError(f"{Path(path).name} não contém faixa de áudio")
            st.thread_type = "AUTO"
            rs = av.AudioResampler(format="s16", layout="mono", rate=SR)
            n = 0
            for frame in c.decode(st):
                for out in rs.resample(frame):
                    parts.append(out.to_ndarray().reshape(-1).copy())
                n += 1
                if cancel is not None and n % 2000 == 0 and cancel.is_set():
                    raise AudioError("cancelado")
            for out in rs.resample(None):
                parts.append(out.to_ndarray().reshape(-1).copy())
    except AudioError:
        raise
    except Exception as e:  # arquivo corrompido, formato não suportado
        if parts:  # arquivo truncado: aproveita o que foi lido
            pass
        else:
            raise AudioError(f"Falha ao decodificar {Path(path).name}: {e}") from e
    if not parts:
        raise AudioError(f"{Path(path).name} não contém áudio")
    pcm = np.concatenate(parts)
    del parts
    audio = pcm.astype(np.float32)
    audio *= 1.0 / 32768.0
    return audio


def estimated_ram_mb(duration_s: float) -> int:
    return int(duration_s * SR * 4 * 2.2 / (1024 * 1024)) + 200  # pico durante decodificação


def write_wav16(path: str | Path, audio: np.ndarray) -> None:
    pcm = np.clip(audio, -1.0, 1.0)
    pcm = (pcm * 32767.0).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def fmt_hms(seconds: float) -> str:
    s = int(round(max(0.0, seconds)))
    return f"{s // 3600:02d}:{(s % 3600) // 60:02d}:{s % 60:02d}"
